package com.example.eventura;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FullEventuraBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
