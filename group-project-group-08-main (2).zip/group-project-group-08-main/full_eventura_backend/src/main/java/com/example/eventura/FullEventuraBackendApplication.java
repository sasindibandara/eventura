package com.example.eventura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FullEventuraBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(FullEventuraBackendApplication.class, args);
    }

}
