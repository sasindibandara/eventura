package com.example.eventura.exception;

public class
ResourceConflictException extends RuntimeException {
    public ResourceConflictException(String message) {
        super(message);
    }
}